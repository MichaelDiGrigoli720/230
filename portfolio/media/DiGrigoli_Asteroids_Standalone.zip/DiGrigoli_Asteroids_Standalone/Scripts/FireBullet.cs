﻿using UnityEngine;
using System.Collections.Generic;

public class FireBullet : MonoBehaviour
{
	public GameObject bullet;
	Vector3 shipFront;
	int maxBullets = 3;

	// Use this for initialization
	void Start ()
	{
		shipFront = new Vector3(0, 0, 0);
	}
	
	// Update is called once per frame
	void Update ()
	{
		if(Input.GetKeyDown(KeyCode.Space))
		{
				shipFront = transform.position + 1 * transform.right;
				Instantiate(bullet, shipFront, Quaternion.identity);
		}
	}
}
