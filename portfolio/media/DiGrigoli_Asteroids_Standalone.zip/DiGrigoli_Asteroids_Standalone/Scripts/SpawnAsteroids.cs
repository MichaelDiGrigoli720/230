﻿using UnityEngine;
using System.Collections;

public class SpawnAsteroids : MonoBehaviour
{
	public GameObject[] largeAsteroids = new GameObject[3];

	int maxAsteroids;
	public int asteroidCount;

	int lCycle;
	int leftRight;
	// Use this for initialization
	void Start ()
	{
		maxAsteroids = 6;
		asteroidCount = 0;
		lCycle = 0;
		leftRight = 0;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if(Random.Range(1,10)>5)
		{
			leftRight = 1;
		}
		else
		{
			leftRight = -1;
		}
		if(asteroidCount <= maxAsteroids)
		{
			Instantiate(largeAsteroids[lCycle], new Vector3(7.5f*leftRight, Random.Range(-5f,5f), 0), Quaternion.identity);
			asteroidCount++;
			lCycle++;
			if(lCycle >= largeAsteroids.Length)
			{
				lCycle = 0;
			}
		}
	}
}
