﻿using UnityEngine;
using System.Collections;

public class MoveShip : MonoBehaviour
{
	Vector3 shipPos;

	Vector3 direction;

	public Vector3 velocity;
	float maxVel;

	Vector3 accel;
	float accelRate;
	float decelRate;

	// Use this for initialization
	void Start ()
	{
		shipPos = new Vector3(0, 0, 0);

		direction = transform.right;

		velocity = new Vector3(0, 0, 0);
		maxVel = .7f;

		accel = new Vector3(0, 0, 0);
		accelRate = .02f;
		decelRate = .9f;
	}
	
	// Update is called once per frame
	void Update ()
	{
		// set acceleration
		accel = direction * accelRate;

		//move
		if (Input.GetKey(KeyCode.UpArrow))
		{
			velocity += accel;
			velocity = Vector3.ClampMagnitude(velocity, maxVel);
		}
		else
		{
			velocity = velocity * decelRate;
		}

		shipPos += velocity;

		// turn
		if(Input.GetKey(KeyCode.RightArrow))
		{
			transform.Rotate(Vector3.back*3);
			direction = transform.right;
		}
		if(Input.GetKey(KeyCode.LeftArrow))
		{
			transform.Rotate(Vector3.forward*3);
			direction = transform.right;
		}


		// wrap vehicle
		if (shipPos.x > 7f)
		{
			shipPos.x = -7f;
		}
		if (shipPos.x < -7f)
		{
			shipPos.x = 7f;
		}
		if (shipPos.y > 5f)
		{
			shipPos.y = -5f;
		}
		if (shipPos.y < -5f)
		{
			shipPos.y = 5f;
		}

		// "Draw" the vehicle at its calculated position
		transform.position = shipPos;
	}
}
