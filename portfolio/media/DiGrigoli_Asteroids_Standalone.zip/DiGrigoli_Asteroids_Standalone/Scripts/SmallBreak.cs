﻿using UnityEngine;
using System.Collections;

public class SmallBreak : MonoBehaviour
{
	Vector3 velocity;
	Vector3 asteroidPos;

	GameObject scene;
	SpawnAsteroids spawn;

	// Use this for initialization
	void Start ()
	{
		velocity = new Vector3(Random.Range(-.1f, .1f), Random.Range(-.1f, .1f), 0);
		asteroidPos = transform.position;

		scene = GameObject.Find("scene_manager");
		spawn = scene.GetComponent<SpawnAsteroids>();
	}
	
	// Update is called once per frame
	void Update ()
	{
		asteroidPos += velocity;
		transform.position = asteroidPos;

		if (asteroidPos.x > 7.5f)
		{
			asteroidPos.x = -7.5f;
		}
		if (asteroidPos.x < -7.5f)
		{
			asteroidPos.x = 7.5f;
		}
		if (asteroidPos.y > 5f)
		{
			asteroidPos.y = -5f;
		}
		if (asteroidPos.y < -5f)
		{
			asteroidPos.y = 5f;
		}
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.name == "bullet(Clone)")
		{
			Destroy(gameObject);
			spawn.asteroidCount--;
			GameObject.Find("score_text").GetComponent<TextMesh>().text = UpdateScore(GameObject.Find("score_text").GetComponent<TextMesh>().text, 50);
		}
		if (col.gameObject.name == "Ship_Container")
		{
			if (GameObject.Find("Life3") != null)
			{
				Destroy(GameObject.Find("Life3"));
				Destroy(gameObject);
				spawn.asteroidCount--;
			}
			else if (GameObject.Find("Life2") != null)
			{
				Destroy(GameObject.Find("Life2"));
				Destroy(gameObject);
				spawn.asteroidCount--;
			}
			else if (GameObject.Find("Life1") != null)
			{
				Destroy(GameObject.Find("Life1"));
				Destroy(gameObject);
				spawn.asteroidCount--;
				Destroy(GameObject.Find("Ship_Container"));
			}
		}
	}

	public string UpdateScore(string current, int point)
	{
		int curScore = int.Parse(current);
		curScore += point;
		return "" + curScore;
	}
}
