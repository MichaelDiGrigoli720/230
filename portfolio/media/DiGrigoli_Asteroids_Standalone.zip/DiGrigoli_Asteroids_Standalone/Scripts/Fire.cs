﻿using UnityEngine;
using System.Collections;

public class Fire : MonoBehaviour
{
	Vector3 velo;
	Vector3 bulletPos;
	GameObject ship;
	// Use this for initialization
	void Start ()
	{
		ship = GameObject.Find("Ship_Container");
		bulletPos = ship.transform.position + 1 * ship.transform.right;
		velo = ship.transform.right/2f;
	}
	
	// Update is called once per frame
	void Update ()
	{
		bulletPos += velo;
		transform.position = bulletPos;
		if (bulletPos.x > 7f)
		{
			Destroy(gameObject);
		}
		if (bulletPos.x < -7f)
		{
			Destroy(gameObject);
		}
		if (bulletPos.y > 5f)
		{
			Destroy(gameObject);
		}
		if (bulletPos.y < -5f)
		{
			Destroy(gameObject);
		}
	}
}
