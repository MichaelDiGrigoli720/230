﻿using UnityEngine;
using System.Collections;

public class Break : MonoBehaviour
{
	Vector3 velocity;
	Vector3 asteroidPos;
	int maxAsteroids;
	int sCycle;
	public GameObject[] smallAsteroids = new GameObject[3];
	GameObject scene;
	SpawnAsteroids spawn;

	// Use this for initialization
	void Start ()
	{
		velocity = new Vector3(Random.Range(-.1f, .1f), Random.Range(-.1f, .1f), 0);
		asteroidPos = transform.position;
		maxAsteroids = 8;
		sCycle = 0;
		scene = GameObject.Find("scene_manager");
		spawn = scene.GetComponent<SpawnAsteroids>();
	}
	
	// Update is called once per frame
	void Update ()
	{
		asteroidPos += velocity;
		transform.position = asteroidPos;

		if (asteroidPos.x > 7.5f)
		{
			asteroidPos.x = -7.5f;
		}
		if (asteroidPos.x < -7.5f)
		{
			asteroidPos.x = 7.5f;
		}
		if (asteroidPos.y > 5f)
		{
			asteroidPos.y = -5f;
		}
		if (asteroidPos.y < -5f)
		{
			asteroidPos.y = 5f;
		}
	}

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.name == "bullet(Clone)")
		{
			Destroy(gameObject);
			spawn.asteroidCount--;
			SpawnSmallAsteroids();
			GameObject.Find("score_text").GetComponent<TextMesh>().text = UpdateScore(GameObject.Find("score_text").GetComponent<TextMesh>().text, 20);
		}
		if(col.gameObject.name == "Ship_Container")
		{
			if (GameObject.Find("Life3") != null)
			{
				Destroy(GameObject.Find("Life3"));
				Destroy(gameObject);
				spawn.asteroidCount--;
			}
			else if (GameObject.Find("Life2") != null)
			{
				Destroy(GameObject.Find("Life2"));
				Destroy(gameObject);
				spawn.asteroidCount--;
			}
			else if (GameObject.Find("Life1") != null)
			{
				Destroy(GameObject.Find("Life1"));
				Destroy(gameObject);
				spawn.asteroidCount--;
				Destroy(GameObject.Find("Ship_Container"));
			}
		}
	}

	void SpawnSmallAsteroids()
	{
		
		if(spawn.asteroidCount < maxAsteroids)
		{
			Instantiate(smallAsteroids[sCycle], asteroidPos, Quaternion.identity);
			sCycle++;
			if(sCycle >= smallAsteroids.Length)
			{
				sCycle = 0;
			}
			Instantiate(smallAsteroids[sCycle], asteroidPos, Quaternion.identity);
			sCycle++;
			if (sCycle >= smallAsteroids.Length)
			{
				sCycle = 0;
			}
		}
	}

	public string UpdateScore(string current, int point)
	{
		int curScore = int.Parse(current);
		curScore += point;
		return "" + curScore;
	}
}
